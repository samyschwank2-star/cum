'''
    Cumination
    Copyright (C) 2016 Whitecream, hdgdl

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
import os
import sqlite3
import time
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('naked', '[COLOR hotpink]Naked[/COLOR]', 'https://www.naked.com/', 'naked.png', 'naked', True)


def _select_hls_variant(master_url, headers):
    master = utils.request_text(master_url, headers=headers, timeout=15, retries=1, error='return')
    if not master.lstrip().startswith('#EXTM3U'):
        return master_url

    variants = []
    lines = [line.strip() for line in master.splitlines() if line.strip()]
    for idx, line in enumerate(lines):
        if not line.startswith('#EXT-X-STREAM-INF'):
            continue
        uri = lines[idx + 1] if idx + 1 < len(lines) else ''
        if not uri or uri.startswith('#'):
            continue
        bandwidth = 0
        match = re.search(r'BANDWIDTH=(\d+)', line)
        if match:
            bandwidth = int(match.group(1))
        variants.append((bandwidth, urllib_parse.urljoin(master_url, uri)))

    if not variants:
        return master_url
    variants.sort(key=lambda item: item[0], reverse=True)
    selected = variants[0][1]
    utils.kodilog('Naked selected HLS variant: {0}'.format(selected.split('?', 1)[0]), utils.xbmc.LOGDEBUG)
    return selected


@site.register(default_mode=True)
def Main():
    female = True if utils.addon.getSetting("chatfemale") == "true" else False
    male = True if utils.addon.getSetting("chatmale") == "true" else False
    trans = True if utils.addon.getSetting("chattrans") == "true" else False
    site.add_dir('[COLOR red]Refresh naked.com images[/COLOR]', '', 'clean_database', '', Folder=False)
    if female:
        site.add_dir('[COLOR hotpink]Females[/COLOR]', site.url + 'live/girls/', 'List', '', 1)
    if male:
        site.add_dir('[COLOR hotpink]Males[/COLOR]', site.url + 'live/guys/', 'List', '', 1)
    if trans:
        site.add_dir('[COLOR hotpink]Transsexual[/COLOR]', site.url + 'live/trans/', 'List', '', 1)
    utils.eod()


@site.register()
def List(url):
    if utils.addon.getSetting("chaturbate") == "true":
        clean_database(False)

    data = utils._getHtml(url, site.url)
    data = re.compile(r"models':\s*(.*?),\s*'", re.DOTALL | re.IGNORECASE).findall(data)[0]
    data = re.sub(r'\s\s+', '', data)
    data = data[:-2] + ']'
    models = json.loads(data)
    for model in models:
        name = model.get('model_seo_name').replace('-', ' ').title()
        age = model.get('age')
        subject = utils.cleantext(model.get('tagline', '') if utils.PY3 else model.get('tagline', '').encode('utf8'))
        if model.get('location'):
            subject += "[CR][CR][COLOR deeppink]Location: [/COLOR]{0}[CR][CR]".format(
                model.get('location') if utils.PY3 else model.get('location').encode('utf8'))
        if model.get('topic'):
            subject += utils.cleantext(model.get('topic') if utils.PY3 else model.get('topic').encode('utf8'))
        status = model.get('room_status') if model.get('room_status') != 'In Open' else ''
        name = name + " [COLOR deeppink][" + age + "][/COLOR] " + status
        mid = model.get('model_id')
        img = 'https://live-screencaps.vscdns.com/{0}-desktop.jpg'.format(mid)
        videourl = 'https://ws.vs3.com/chat/get-stream-urls.php?model_id={0}&video_host={1}'.format(
            mid, model.get('video_host'))
        site.add_download_link(name, videourl, 'Playvid', img, subject, noDownload=True)
    utils.eod()


@site.register(clean_mode=True)
def clean_database(showdialog=True):
    conn = sqlite3.connect(utils.TRANSLATEPATH("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".vscdns.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(utils.TRANSLATEPATH("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".vscdns.com")
            if showdialog:
                utils.notify('Finished', 'naked.com images cleared')
    except:
        pass


@site.register()
def Playvid(url, name):
    playmode = 0  # int(utils.addon.getSetting('chatplay'))
    url = "{0}&t={1}".format(url, int(time.time() * 1000))
    params = urllib_parse.parse_qs(url.split('?')[1])
    murl = '{0}webservices/chat-room-interface.php?a=login_room&model_id={1}&t={2}'.format(
        site.url, params['model_id'][0], params['t'][0])
    mdata = utils._getHtml(murl, site.url)
    if mdata:
        mdata = json.loads(mdata).get('config', {}).get('room')
        if mdata:
            if mdata.get('status') != 'O':
                utils.notify('Model not in freechat')
                return None
        else:
            utils.notify('Model Offline')
            return None
    else:
        utils.notify('Oh oh', 'Couldn\'t find a playable webcam link')
        return None

    vdata = utils._getHtml(url, site.url)
    if vdata:
        vdata = json.loads(vdata).get('data')
    else:
        utils.notify('Oh oh', 'Couldn\'t find a playable webcam link')
        return

    if playmode == 0:
        streams = vdata.get('hls') or []
        sdata = streams[0] if streams else None
        stream_path = sdata.get('url') if sdata else ''
        if stream_path:
            videourl = 'https:{0}'.format(stream_path)
        else:
            utils.kodilog('Naked invalid HLS stream for {0}: {1}'.format(name, stream_path), utils.xbmc.LOGDEBUG)
            utils.notify('Naked', 'Model offline/private or stream unavailable')
            return

    elif playmode == 1:
        sdata = vdata.get('flash')[0]
        if sdata:
            swfurl = site.url + "chat/flash/live-video-player-nw2.swf"
            videourl = "rtmp://{0} app=liveEdge/{3} swfUrl={1} pageUrl={2} playpath=mp4:{3}".format(sdata.get('stream_host'), swfurl, site.url, sdata.get('stream_name'))
        else:
            utils.notify('Oh oh', 'Couldn\'t find a playable webcam link')
            return

    if playmode == 0:
        headers = {
            'User-Agent': utils.USER_AGENT,
            'Referer': site.url,
            'Origin': site.url[:-1]
        }
        videourl = _select_hls_variant(videourl, headers)
        utils.play_hls(name, videourl, headers=headers, site_name='Naked')
    else:
        vp = utils.VideoPlayer(name)
        vp.play_from_direct_link(videourl)
