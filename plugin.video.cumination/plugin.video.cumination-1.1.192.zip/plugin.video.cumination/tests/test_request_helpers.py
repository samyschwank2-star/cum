import gzip
import json
import os
import sys
import tempfile
import threading
import time
import types
import unittest

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, ROOT)
sys.argv = ['plugin://plugin.video.cumination', '1', '']


class _Addon(object):
    settings = {
        'cache_time': '1',
        'current_ua': 'UnitTest UA',
        'last_ua_create': str(int(time.time())),
        'fs_enable': 'false',
    }

    def __init__(self, addon_id=None):
        self.addon_id = addon_id

    def getSetting(self, key):
        return self.settings.get(key, '')

    def setSetting(self, key, value):
        self.settings[key] = value

    def getAddonInfo(self, key):
        if self.addon_id == 'xbmc.addon' and key == 'version':
            return '21.0'
        if key == 'path':
            return ROOT
        if key == 'profile':
            return tempfile.gettempdir()
        if key == 'version':
            return '1.1.189'
        return ''

    def getLocalizedString(self, value):
        return str(value)


class _Dialog(object):
    def notification(self, *args, **kwargs):
        pass

    def ok(self, *args, **kwargs):
        pass


class _DialogProgress(object):
    def update(self, *args, **kwargs):
        pass

    def close(self):
        pass

    def iscanceled(self):
        return False


class _StorageServer(object):
    def __init__(self, *args, **kwargs):
        pass

    def cacheFunction(self, func, *args):
        return func(*args)

    def cacheDelete(self, *args, **kwargs):
        pass


def _install_kodi_stubs():
    xbmc = types.ModuleType('xbmc')
    xbmc.LOGDEBUG = 0
    xbmc.LOGINFO = 1
    xbmc.LOGNOTICE = 1
    xbmc.LOGWARNING = 2
    xbmc.LOGERROR = 3
    xbmc.log = lambda *args, **kwargs: None
    xbmc.sleep = lambda ms: time.sleep(ms / 1000.0)
    xbmc.translatePath = lambda p: tempfile.gettempdir() if p.startswith('special://') else p
    xbmc.getSkinDir = lambda: 'estuary'
    xbmc.executebuiltin = lambda *args, **kwargs: None
    xbmc.executeJSONRPC = lambda payload: '{}'

    xbmcgui = types.ModuleType('xbmcgui')
    xbmcgui.Dialog = _Dialog
    xbmcgui.DialogProgress = _DialogProgress
    xbmcgui.ListItem = lambda *args, **kwargs: object()

    xbmcplugin = types.ModuleType('xbmcplugin')
    xbmcplugin.endOfDirectory = lambda *args, **kwargs: None
    xbmcplugin.addDirectoryItem = lambda *args, **kwargs: True
    xbmcplugin.setContent = lambda *args, **kwargs: None
    xbmcplugin.setResolvedUrl = lambda *args, **kwargs: None

    xbmcaddon = types.ModuleType('xbmcaddon')
    xbmcaddon.Addon = _Addon

    xbmcvfs = types.ModuleType('xbmcvfs')
    xbmcvfs.translatePath = lambda p: tempfile.gettempdir() if p.startswith('special://') else p
    xbmcvfs.exists = os.path.exists
    xbmcvfs.delete = lambda p: os.path.exists(p) and os.remove(p)
    xbmcvfs.File = open

    kodi_six = types.ModuleType('kodi_six')
    kodi_six.xbmc = xbmc
    kodi_six.xbmcgui = xbmcgui
    kodi_six.xbmcplugin = xbmcplugin
    kodi_six.xbmcaddon = xbmcaddon
    kodi_six.xbmcvfs = xbmcvfs

    storage = types.ModuleType('StorageServer')
    storage.StorageServer = _StorageServer

    sys.modules.update({
        'xbmc': xbmc,
        'xbmcgui': xbmcgui,
        'xbmcplugin': xbmcplugin,
        'xbmcaddon': xbmcaddon,
        'xbmcvfs': xbmcvfs,
        'kodi_six': kodi_six,
        'StorageServer': storage,
    })


_install_kodi_stubs()
from resources.lib import utils  # noqa: E402


class Handler(BaseHTTPRequestHandler):
    attempts = 0

    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == '/json':
            self._send(200, b'{"ok": true}', 'application/json')
        elif self.path == '/bad-json':
            self._send(200, b'{bad', 'application/json')
        elif self.path == '/gzip':
            body = gzip.compress(b'compressed')
            self._send(200, body, 'text/plain', {'Content-Encoding': 'gzip'})
        elif self.path == '/retry':
            Handler.attempts += 1
            if Handler.attempts == 1:
                self._send(500, b'nope', 'text/plain')
            else:
                self._send(200, b'ok', 'text/plain')
        elif self.path == '/slow':
            time.sleep(0.2)
            self._send(200, b'slow', 'text/plain')
        else:
            self._send(404, b'', 'text/plain')

    def _send(self, code, body, content_type, extra=None):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            pass


class RequestHelperTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever)
        cls.thread.daemon = True
        cls.thread.start()
        cls.base = 'http://127.0.0.1:{0}'.format(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join()
        cls.server.server_close()

    def test_request_json_success(self):
        self.assertEqual(utils.request_json(self.base + '/json'), {'ok': True})

    def test_request_json_malformed_returns_default(self):
        self.assertEqual(utils.request_json(self.base + '/bad-json', default={}), {})

    def test_request_text_retries_500(self):
        Handler.attempts = 0
        self.assertEqual(utils.request_text(self.base + '/retry', retries=1), 'ok')
        self.assertEqual(Handler.attempts, 2)

    def test_request_text_decodes_gzip(self):
        self.assertEqual(utils.request_text(self.base + '/gzip'), 'compressed')

    def test_request_text_timeout_returns_empty(self):
        self.assertEqual(utils.request_text(self.base + '/slow', timeout=0.05, retries=1), '')


if __name__ == '__main__':
    unittest.main()
